<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Contactos de cada instalação</title>
  </head>
  <body>

    <?php include("menu.php"); ?>

    <div id="contactos">

      <div class="instalacoes_info">
        <h2><a href="instalacoes.php">Instalações</a> &gt; <a href="Braga.php">Braga</a> &gt; Contactos</h2>
      </div>

    </div>
  </body>
</html>
