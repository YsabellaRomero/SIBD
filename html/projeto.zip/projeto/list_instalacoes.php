<?php

  require_once('config/init.php');
  require_once('database/Instalacoes.php');

  $instalacoes = getAllInstalacoes();
  var_dump($instalacoes) 

  $title = "Lista de Instalações";
  include("templates/menu.php");

?>
