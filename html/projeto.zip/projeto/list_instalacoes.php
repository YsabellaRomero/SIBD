<?php
  require_once('config/init.php');
  require_once('database/Instalacoes.php');

  $categories = getAllInstacoes();

  include('templates/menu.php');
  //include('templates/header.php');
  //include('templates/list_categories.php');
  //include('templates/footer.php');
?>
