<sec id="treinos">
<h2><a href="list_instalacoes.php">Instalações</a> &gt; <a><?= $instalacao_info['localizacao'] ?></a> &gt; <a>Treinos</a></h2>
  <section class="list">
      <ul>
        <li>
          <a href="list_pt.php?id=<?=$instalacao_info['id']?>">Treino Pessoal</a><a href="list_aulas.php?id=<?=$instalacao_info['id']?>">Aulas</a></li>
      </ul>
  </section>
</div>
</body>
</html>
