  <section id="treinos">
  <h2><a href="list_instalacoes.php">Instalações</a> &gt; <a><?= $instalacao_info['localizacao'] ?></a> &gt; <a> <?= $modalidade['nome']?></a></h2>
    <section class="list">
      <h1> <?= $descricao[0][strftime('%s',hora_inicio)] ?></h1>
    </section>

    </section>
  </body>
</html>
