
      <div id="instalacoes">
        <h2><a href="instalacoes.php">Instalações</a></h2>
        <section class="list">
          <?php foreach ($instalacoes as $instalacao) { ?>
            <article>
              <h3><a href="../list_instalacoes.php"><?php $instalacao["localizacao"]?></a></h3>
              <img src="imagens/<?php $row["localizacao"] ?>/lobbie.jpg">
            </arcticle>
          <?php } ?>
        </section>
      </div>

  </body>
</html>
