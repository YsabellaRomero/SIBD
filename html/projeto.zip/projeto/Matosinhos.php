<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Matosinhos info</title>
  </head>
  <body>
    <?php include("menu.php"); ?>

    <div class="instalacoes_info">
      <h2>
        <ul>
          <li class="dropdown">
            <a href="instalacoes.php" class="dropbtn">Instalações &gt; </a>
            <div class="dropdown-content">
              <a href="Boavista.php">Boavista</a>
              <a href="Matosinhos.php">Matosinhos</a>
              <a href="Braga.php">Braga</a>
            </div>
          </li>
          <li><a href="#">Matosinhos</a></li>
        </ul>
      </h2>
      <ul>
        <li><a href="contactos_boavista.php">Contactos</a></li>
        <li><a href="horarios_boavista.php">Horarios</a></li>
      </ul>
    </div>
  </body>
</html>
