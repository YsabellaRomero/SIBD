<?php

function getAllInstacoes() {
  global $dbh;
  $stmt = $dbh->prepare('SELECT * FROM Instalacoes');
  $stmt->execute();
  return $stmt->fetchAll();
}

function getInstalacoesById($id) {
  global $dbh;
  $stmt = $dbh->prepare('SELECT * FROM Instalacoes WHERE id = ?');
  $stmt->execute(array($id));
  return $stmt->fetch();
}

?>
