<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>About us</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="style.css" rel="stylesheet">
    <link href="layout.css" rel="stylesheet">
  </head>
  <body>

    <?php include("menu.php"); ?>

    <header>
      <h1>Sobre Nós</h1>
    </header>

    <div class="about_us">
      <p> A cadeia de ginásios M.Y. Space foi criada pela Maria Sanches e Ysabella Romero e tudo começou com um projeto para uma matéria da Faculdade de Engenharia do Porto, "Sistemas de Base de Dados", em dezembro de 2020.</p>
      <p>Este projeto despertou o interesse das duas e com os conhecimentos da matéria, decidiram recorrer aos contactos de amigos e colegas em Gestão, Desporto, entre outros, para a encontrar as pessoas indicadas para realmente criar o primeiro ginásio, no qual foi na Boavista. Bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla</p>
    </div>
  </body>
</html>
